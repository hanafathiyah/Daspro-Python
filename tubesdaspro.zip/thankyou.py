def thankyou():
    print("  _______  _                    _      __     __             _ ")
    print(" |__   __|| |                  | |     \ \   / /            | |")
    print("    | |   | |__    __ _  _ __  | | __   \ \_/ /___   _   _  | |")
    print("    | |   | '_ \  / _` || '_ \ | |/ /    \   // _ \ | | | | | |")
    print("    | |   | | | || (_| || | | ||   <      | || (_) || |_| | |_|")
    print("    |_|   |_| |_| \__,_||_| |_||_|\_\     |_| \___/  \__,_| (_)")  
    print("")                                                   
    print("\tTerima kasih telah menggunakan kantong ajaib!")
