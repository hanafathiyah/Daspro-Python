from color import blue
def thankyou():
    print(blue("  _______  _                    _      __     __             _ "))
    print(blue(" |__   __|| |                  | |     \ \   / /            | |"))
    print(blue("    | |   | |__    __ _  _ __  | | __   \ \_/ /___   _   _  | |"))
    print(blue("    | |   | '_ \  / _` || '_ \ | |/ /    \   // _ \ | | | | | |"))
    print("    | |   | | | || (_| || | | ||   <      | || (_) || |_| | |_|")
    print("    |_|   |_| |_| \__,_||_| |_||_|\_\     |_| \___/  \__,_| (_)")
    print("")                                                   
    print("\tTerima kasih telah menggunakan kantong ajaib!")
