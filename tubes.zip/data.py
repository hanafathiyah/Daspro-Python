global user, gadget, gadget_borrow_history, gadget_return_history, consumable, consumable_history
global header_user, header_gadget, header_gadget_borrow_history, header_gadget_return_history, header_consumable, header_consumable_history
global user_login 

user                   = []
gadget                 = []
gadget_borrow_history  = []
gadget_return_history  = []
consumable             = []
consumable_history     = []

header_user                   = []
header_gadget                 = []
header_gadget_borrow_history  = []
header_gadget_return_history  = []
header_consumable             = []
header_consumable_history     = []

user_login = []