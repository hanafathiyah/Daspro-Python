import data
from LoadData import load_data
from adding_function import isAdmin
from adding_function import isUser
from desain import carirarity_header

# load_data("folder_isi")

def mencari_rarity() :
        carirarity_header()
        datas = data.gadget
        rarity = input("Masukkan rarity: ")
        print("\nHasil pencarian:\n")

        for array in (datas):
            if (rarity == array[4]):
                print("Nama :", array[1])
                print("Deskripsi :", array[2])
                print("Jumlah :", array[3], "buah")
                print("Rarity :", array[4])
                print("Tahun Ditemukan :", array[5] ,"\n")
