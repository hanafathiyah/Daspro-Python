def black(s):
    return "\033[30m"+s+"\033[0m"

def red(s):
    return "\033[31m"+s+"\033[0m"

def green(s):
    return "\033[32m"+s+"\033[0m"

def yellow(s):
    return "\033[33m"+s+"\033[0m"

def blue(s):
    return "\033[34m"+s+"\033[0m"

def magenta(s):
    return "\033[35m"+s+"\033[0m"

def cyan(s):
    return "\033[36m"+s+"\033[0m"

def white(s):
    return "\033[37m"+s+"\033[0m"

def gray(s):
    return "\033[90m"+s+"\033[0m"

def brightred(s):
    return "\033[91m"+s+"\033[0m"

def brightgreen(s):
    return "\033[92m"+s+"\033[0m"

def brightyellow(s):
    return "\033[93m"+s+"\033[0m"

def brightblue(s):
    return "\033[94m"+s+"\033[0m"

def brightmagenta(s):
    return "\033[95m"+s+"\033[0m"

def brightcyan(s):
    return "\033[96m"+s+"\033[0m"

def brightwhite(s):
    return "\033[97m"+s+"\033[0m"